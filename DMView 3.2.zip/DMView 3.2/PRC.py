'''
PRC.py (PreRequisites Check)
'''
def versiontuple(v):
    return tuple(map(int, (v.split("."))))

import os,sys
import glob
python_path, _ = os.path.split(sys.executable)
py_ver = sys.version.split('(')[0]

msg = ''
flag = 1
try:
    msg = 'Avaible PSS/e minor versions under Python '+py_ver+ ': \n'
    psse35_lst = glob.glob(python_path + r"\\Lib\\site-packages\\psse35*.py", recursive = True) + glob.glob(python_path + r"\\Lib\\site-packages\\psse35*.pyc", recursive = True)
    psse_ver_lst = []
    for psse35_i in psse35_lst:
        psse_ver = os.path.splitext(os.path.basename(psse35_i))[0]
        if len(psse_ver)>6:
            if psse_ver not in psse_ver_lst:
                psse_ver_lst.append(psse_ver)
                msg = msg + '     ' + psse_ver +'\n'
    msg = msg + 'Please only use available PSS/e versions under Python '+ py_ver
    import psse35
    import psspy
    psspy.psseinit()
except:
    msg = 'PSSE 35 NOT available\n'
    flag = 0
try:
    import openpyxl
except:
    msg = msg + 'Please install openpyxl using python pip: pip install openpyxl\n' 
    flag = 0
try:
    import matplotlib
    if versiontuple(matplotlib.__version__)>versiontuple("3.4.3"):
        msg = msg + 'Your matplotlib may not work with psse plot\n'
        msg = msg + 'Please install matplotlib (3.4.3) using python pip: pip install matplotlib==3.4.3\n'
        flag = 0
except:
    msg = msg + 'Please install matplotlib (3.4.3) using python pip: pip install matplotlib==3.4.3\n'
    flag = 0


 
import tkinter
from tkinter import messagebox
top =  tkinter.Tk()
top.withdraw()

if flag:
    msg = msg + '\n\nDMView ready to use\n\n'
    messagebox.showinfo("SUCCESS",msg)
else:
    messagebox.showinfo("ERROR!!!",msg)


 
